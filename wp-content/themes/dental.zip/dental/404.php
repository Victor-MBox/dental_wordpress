<?php
/**
 * The template for displaying 404 pages (not found)
 */

get_header(); ?>

<div style="margin-bottom: 70vh;" class="container">
	<h1 class="page-title"><?php _e('Страница не найдена', 'dental'); ?></h1>
</div>

<?php
get_footer();
?>