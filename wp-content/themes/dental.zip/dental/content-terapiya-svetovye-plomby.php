<?php
/* 
Template Name: ТЕРАПИЯ - Световые пломбы
*/
?>

<?php
get_header();
?>

<div class="page">
    <div class="page-content">
        <div class="page-content__container container">

            <section class="page-contetn__wrapper" id="content-page">

                <div class="page-content__chapter">
                    <div class="page-content__banner page-content__banner_plomby">
                        <div class="page-content__name">Световые <br>пломбы</div>
                        <div class="page-content__label">от <span>4 000₽</span></div>
                        <div class="page-content__btn-call">
                            <button class="btn-call" data-modal="mainModal">
                                <div class="btn-call__img"></div>
                                <div class="btn-call__text">Оставьте номер телефона <br>мы вам перезвоним</div>
                            </button>
                        </div>
                    </div>
                    <div class="page-content__first-decor">
                        <img src="<?php echo bloginfo('template_url'); ?>/assets/img/icons/page/page-decor-4.svg" alt="">
                    </div>

                    <div class="page-content__text">Пломбирование кариозных полостей ― заключительный этап лечения зуба. Выбрав световые пломбы, вы получаете прочность, долговечность и высокий эстетический результат.
                    </div>
                </div>

                <div class="page-content__chapter">
                    <div class="page-content__title">Что такое световые пломбы</div>
                    <div class="page-content__text">Качество лечения зуба во многом зависит от пломбировочного материала. Гелиокомпозит это состав, застывающий под действием УФ-лучей, что дает стоматологу возможность тщательно формировать идеальный контур реставрируемого зуба. Фотокомпозит пластичный, он заполняет полости без пустот или воздушных карманов. Материал содержит стеклокерамику и пигменты, придающие прочность и натуральный вид. Обычная пломба химического состава быстро застывает, и сформировать красивый зуб гораздо труднее.
                        <br><br>
                        <b>Преимущества:</b>
                    </div>

                    <div class="page-about-section__advantages-wrapper">
                        <div class="page-about-section__advantages">
                            <img src="<?php echo bloginfo('template_url'); ?>/assets/img/icons/page/about/ic-about-01.svg" alt="">
                            <div class="page-about-section__advantages-text">эстетичность ― большая палитра оттенков позволят идеально подобрать цвет, подходящий к своей эмали</div>
                        </div>

                        <div class="page-about-section__advantages">
                            <img src="<?php echo bloginfo('template_url'); ?>/assets/img/icons/page/about/ic-about-02.svg" alt="">
                            <div class="page-about-section__advantages-text">герметичность – высокая степень прилегания к стенкам исключает проникновение бактерий</div>
                        </div>

                        <div class="page-about-section__advantages">
                            <img src="<?php echo bloginfo('template_url'); ?>/assets/img/icons/page/about/ic-about-03.svg" alt="">
                            <div class="page-about-section__advantages-text">минимальная усадка предотвращает возникновение участков кариеса на границе пломбы и тканей зуба</div>
                        </div>

                        <div class="page-about-section__advantages">
                            <img src="<?php echo bloginfo('template_url'); ?>/assets/img/icons/page/about/ic-about-04.svg" alt="">
                            <div class="page-about-section__advantages-text">высокая прочность при любой жевательной нагрузке</div>
                        </div>

                        <div class="page-about-section__advantages">
                            <img src="<?php echo bloginfo('template_url'); ?>/assets/img/icons/page/about/ic-about-05.svg" alt="">
                            <div class="page-about-section__advantages-text">долговечность до 10-15 лет</div>
                        </div>

                        <div class="page-about-section__advantages">
                            <img src="<?php echo bloginfo('template_url'); ?>/assets/img/icons/page/about/ic-about-06.svg" alt="">
                            <div class="page-about-section__advantages-text">безопасность для здоровья – материал нетоксичный, гипоаллергенный</div>
                        </div>
                    </div>

                    <div class="page-content__text">
                        <b>Показания:</b>
                    </div>
                    <div class="page-content__list">
                        <ul>
                            <li>кариозная полость;</li>
                            <li>изменение цвета эмали;</li>
                        </ul>
                        <ul>
                            <li>клиновидные дефекты эмали трещины сколы;</li>
                            <li>разрушение коронки зуба не 30-40%.</li>
                        </ul>
                    </div>
                </div>

                <div class="page-content__chapter">
                    <div class="page-content__title">Как проходит процедура</div>
                    <div class="page-content__text">Пациенту проводят местную анестезию, выбирают оттенок пломбы по шкале. Процедура безболезненна и проходит в комфортной обстановке. <br><br>
                        <b>Этапы пломбирования:</b>
                    </div>

                    <div class="page-content__list">
                        <ul>
                            <li>поврежденные ткани удаляются;</li>
                            <li>формируется полость под пломбу;</li>
                            <li>наносится препарат, улучшающий сцепление световой пломбы с тканью зуба;</li>
                            <li> послойно наносится фотокомпозит и отвердевает под УФ-лампой;</li>
                            <li>шлифовка и полировка пломбы придает естественный блеск.</li>
                        </ul>
                    </div>

                    <div class="page-content__text">В результате – идеально восстановленная форма зубной единицы. Процесс занимает 30-40 минут. В клинике «Зубки Всем» реставрацию фотопломбами проводят квалифицированные врачи с большим опытом. Запишитесь на прием на нашем сайте, мы гарантируем высокое качество пломбирования и ослепительность вашей улыбки.
                    </div>
                </div>

                <!-- Акция -->
                <div class="page-content__chapter">
                    <div class="page-content__infobox">
                        Проводим терапевтическое лечение каналов пломбами без боли. Даем гарантию 18 месяцев. В течение гарантийного срока перелечиваем бесплатно!
                    </div>
                </div>

                <!-- Цены -->
                <div class="page-content__chapter">
                    <div class="page-content__title">Цены</div>

                    <div class="page-content__table">

                        <div class="page-content__column-table">
                            <img src="<?php echo bloginfo('template_url'); ?>/assets/img/icons/page/page-price.svg" alt="">
                            <p>Услуга</p>
                        </div>

                        <div class="page-content__column-table">
                            <img src="<?php echo bloginfo('template_url'); ?>/assets/img/icons/page/page-price-2.svg" alt="">
                            <p>Стоимость</p>
                        </div>
                    </div>

                    <table class="table-service">
                        <tr>
                            <td class="table-service__name">Наложение временной пломбы</td>
                            <td class="table-service__price">600 ₽</td>
                        </tr>
                        <tr>
                            <td class="table-service__name">Поверхностный кариес (композитная пломба)</td>
                            <td class="table-service__price">4 000 ₽</td>
                        </tr>
                        <tr>
                            <td class="table-service__name">Средний кариес (композитная пломба)</td>
                            <td class="table-service__price">5 500 ₽</td>
                        </tr>
                        <tr>
                            <td class="table-service__name">Поверхностный кариес (композитная пломба)</td>
                            <td class="table-service__price">4 000 ₽</td>
                        </tr>
                        <tr>
                            <td class="table-service__name">Глубокий кариес (композитная пломба)</td>
                            <td class="table-service__price">7 000 ₽</td>
                        </tr>
                    </table>

                    <div class="table-service__btn">
                        <a href="/czeny/" class="btn">Полный прайс-лист</a>
                        <a href="/akczii/" class="btn">Акции</a>
                    </div>
                </div>

                <!-- До-после -->
                <div class="page-content__chapter-home">
                    <div class="page-content__title">До/После</div>

                    <div class="page-content__before-after" id="beforeAfterSlider">

                        <div class="before-after">
                            <span id="before" class="before__btn">ДО</span>
                            <span id="after" class="after__btn">ПОСЛЕ</span>

                            <div class="before-after__gallery">
                                <img src="<?php echo bloginfo('template_url'); ?>/assets/img/page/before-after/portfolio-08-after.jpg" alt="" class="before-after__img">
                                <div class="before-after__gallery-after">
                                    <img src="<?php echo bloginfo('template_url'); ?>/assets/img/page/before-after/portfolio-08-before.jpg" alt="" class="before-after__img">
                                </div>
                            </div>

                            <div class="before-after__procedure procedure">
                                <div class="procedure__column">
                                    <div class="procedure__row-all">

                                        <div class="procedure__img">
                                            <img src="<?php echo bloginfo('template_url'); ?>/assets/img/icons/procedure__img.svg" alt="">
                                        </div>

                                        <div class="procedure__row-wrapper">
                                            <div class="procedure__row">
                                                <div class="procedure__subtitle">Процедура</div>
                                            </div>
                                            <div class="procedure__row">
                                                <div class="procedure__title">Виниры</div>
                                            </div>
                                        </div>
                                    </div>

                                    <a class="btn btn_lilac" href="/galereya/">Больше работ</a>

                                </div>
                                <div class="procedure__text">Были установлены виниры</div>
                            </div>

                        </div>

                        <div class="before-after2">
                            <span id="before2" class="before__btn">ДО</span>
                            <span id="after2" class="after__btn">ПОСЛЕ</span>

                            <div class="before-after2__gallery">
                                <img src="<?php echo bloginfo('template_url'); ?>/assets/img/page/before-after/portfolio-09-after.jpg" alt="" class="before-after2__img">
                                <div class="before-after2__gallery-after">
                                    <img src="<?php echo bloginfo('template_url'); ?>/assets/img/page/before-after/portfolio-09-before.jpg" alt="" class="before-after2__img">
                                </div>
                            </div>
                            <div class="before-after__procedure procedure">
                                <div class="procedure__column">
                                    <div class="procedure__row-all">

                                        <div class="procedure__img">
                                            <img src="<?php echo bloginfo('template_url'); ?>/assets/img/icons/procedure__img.svg" alt="">
                                        </div>

                                        <div class="procedure__row-wrapper">
                                            <div class="procedure__row">
                                                <div class="procedure__subtitle">Процедура</div>
                                            </div>
                                            <div class="procedure__row">
                                                <div class="procedure__title">Гигиена полости рта</div>
                                            </div>
                                        </div>
                                    </div>

                                    <a class="btn btn_lilac" href="/galereya/">Больше работ</a>

                                </div>
                                <div class="procedure__text">Механическое удаление зубного камня и бактериального налета</div>
                            </div>
                        </div>

                        <div class="before-after3">
                            <span id="before3" class="before__btn">ДО</span>
                            <span id="after3" class="after__btn">ПОСЛЕ</span>

                            <div class="before-after3__gallery">
                                <img src="<?php echo bloginfo('template_url'); ?>/assets/img/page/before-after/portfolio-10-after.jpg" alt="" class="before-after3__img">
                                <div class="before-after3__gallery-after">
                                    <img src="<?php echo bloginfo('template_url'); ?>/assets/img/page/before-after/portfolio-10-before.jpg" alt="" class="before-after3__img">
                                </div>
                            </div>
                            <div class="before-after__procedure procedure">
                                <div class="procedure__column">
                                    <div class="procedure__row-all">

                                        <div class="procedure__img">
                                            <img src="<?php echo bloginfo('template_url'); ?>/assets/img/icons/procedure__img.svg" alt="">
                                        </div>

                                        <div class="procedure__row-wrapper">
                                            <div class="procedure__row">
                                                <div class="procedure__subtitle">Процедура</div>
                                            </div>
                                            <div class="procedure__row">
                                                <div class="procedure__title">Установка импланта</div>
                                            </div>
                                        </div>
                                    </div>

                                    <a class="btn btn_lilac" href="/galereya/">Больше работ</a>

                                </div>
                                <div class="procedure__text">Установка импланта</div>
                            </div>
                        </div>

                    </div>

                    <div class="slider-arrows">
                        <button class="slider-arrows__left" id="introSliderPrev" type="button"></button>
                        <button class="slider-arrows__right" id="introSliderNext" type="button"></button>
                    </div>

                </div>

                <!-- Доктора -->
                <div class="page-content__chapter">
                    <div class="page-content__title">Наши специалисты</div>

                    <div class="specialists-section__carousel carousel" id="slickCarouselServise">

                        <div class="carousel__wrapper">
                            <div class="carousel__photo">
                                <img src="<?php echo bloginfo('template_url'); ?>/assets/img/page/doctors/doc-08.jpg" alt="">
                                <div class="carousel__label">
                                    <p>Опыт</p> <span>11 лет</span>
                                </div>
                            </div>
                            <div class="carousel__name"><span>Борисенко</span> <br>Инна Владимировна</div>
                            <div class="carousel__text">Врач стоматолог: <br>терапевт, хирург</div>
                            <button class="btn btn_entry" data-modal="mainModal">Записаться</button>
                        </div>

                        <div class="carousel__wrapper">
                            <div class="carousel__photo carousel__photo_01">
                                <img src="<?php echo bloginfo('template_url'); ?>/assets/img/page/doctors/doc-09.jpg" alt="">
                                <div class="carousel__label carousel__label_red">
                                    <p>Опыт</p> <span>12 лет</span>
                                </div>
                            </div>
                            <div class="carousel__name"><span>Зейналов</span> <br>Зейнал Вилаяддинович</div>
                            <div class="carousel__text">Врач стоматолог: <br>терапевт</div>
                            <button class="btn btn_entry" data-modal="mainModal">Записаться</button>
                        </div>

                        <div class="carousel__wrapper">
                            <div class="carousel__photo carousel__photo_02">
                                <img src="<?php echo bloginfo('template_url'); ?>/assets/img/page/doctors/doc-04.jpg" alt="">
                                <div class="carousel__label carousel__label_lilac">
                                    <p>Опыт</p> <span>12 лет</span>
                                </div>
                            </div>
                            <div class="carousel__name"><span>Сарыбаев</span> <br>Анарбек Муктарбекович</div>
                            <div class="carousel__text">Врач стоматолог: <br>терапевт</div>
                            <button class="btn btn_entry" data-modal="mainModal">Записаться</button>
                        </div>

                        <div class="carousel__wrapper">
                            <div class="carousel__photo carousel__photo_03">
                                <img src="<?php echo bloginfo('template_url'); ?>/assets/img/page/doctors/doc-010.jpg" alt="">
                                <div class="carousel__label carousel__label_yellow">
                                    <p>Опыт</p> <span>32 года</span>
                                </div>
                            </div>
                            <div class="carousel__name"><span>Антоновский</span> <br>Антон
                                Анатольевич</div>
                            <div class="carousel__text">Врач стоматолог: <br>ортопед, главный врач</div>
                            <button class="btn btn_entry" data-modal="mainModal">Записаться</button>
                        </div>

                        <div class="carousel__wrapper">
                            <div class="carousel__photo carousel__photo_03">
                                <img src="<?php echo bloginfo('template_url'); ?>/assets/img/page/doctors/doc-06.jpg" alt="">
                                <div class="carousel__label carousel__label_yellow">
                                    <p>Опыт</p> <span>13 лет</span>
                                </div>
                            </div>
                            <div class="carousel__name"><span>Игонин</span> <br>Василий Валентинович</div>
                            <div class="carousel__text">Врач стоматолог: <br>ортопед, хирург</div>
                            <button class="btn btn_entry" data-modal="mainModal">Записаться</button>
                        </div>

                        <div class="carousel__wrapper">
                            <div class="carousel__photo">
                                <img src="<?php echo bloginfo('template_url'); ?>/assets/img/page/doctors/doc-01.jpg" alt="">
                                <div class="carousel__label">
                                    <p>Опыт</p> <span>7 лет</span>
                                </div>
                            </div>
                            <div class="carousel__name"><span>Хандогин</span> <br>Антон Олегович</div>
                            <div class="carousel__text">Врач стоматолог: <br>ортопед</div>
                            <button class="btn btn_entry" data-modal="mainModal">Записаться</button>
                        </div>

                        <div class="carousel__wrapper">
                            <div class="carousel__photo carousel__photo_01">
                                <img src="<?php echo bloginfo('template_url'); ?>/assets/img/page/doctors/doc-03.jpg" alt="">
                                <div class="carousel__label carousel__label_red">
                                    <p>Опыт</p> <span>12 лет</span>
                                </div>
                            </div>
                            <div class="carousel__name"><span>Журов</span> <br>Илья Владимирович</div>
                            <div class="carousel__text">Врач стоматолог: <br>хирург имплантолог</div>
                            <button class="btn btn_entry" data-modal="mainModal">Записаться</button>
                        </div>

                        <div class="carousel__wrapper">
                            <div class="carousel__photo carousel__photo_02">
                                <img src="<?php echo bloginfo('template_url'); ?>/assets/img/page/doctors/doc-05.jpg" alt="">
                                <div class="carousel__label">
                                    <p>Опыт</p> <span>2 года</span>
                                </div>
                            </div>
                            <div class="carousel__name"><span>Бачулис</span> <br>Марина Александровна</div>
                            <div class="carousel__text">Врач стоматолог: <br>ортодонт, гигиенист</div>
                            <button class="btn btn_entry" data-modal="mainModal">Записаться</button>
                        </div>

                        <div class="carousel__wrapper">
                            <div class="carousel__photo carousel__photo_03">
                                <img src="<?php echo bloginfo('template_url'); ?>/assets/img/page/doctors/doc-07.jpg" alt="">
                                <div class="carousel__label carousel__label_yellow">
                                    <p>Опыт</p> <span>18 лет</span>
                                </div>
                            </div>
                            <div class="carousel__name"><span>Джахбарова</span> <br>Рабият Магомедгаджиевна</div>
                            <div class="carousel__text">Гигиенист, <br>ассистент стоматолога</div>
                            <button class="btn btn_entry" data-modal="mainModal">Записаться</button>
                        </div>

                        <div class="carousel__wrapper">
                            <div class="carousel__photo">
                                <img src="<?php echo bloginfo('template_url'); ?>/assets/img/page/doctors/doc-02.jpg" alt="">
                                <div class="carousel__label carousel__label_lilac">
                                    <p>Опыт</p> <span>10 лет</span>
                                </div>
                            </div>
                            <div class="carousel__name"><span>Байкулова</span> <br>Асият Хамитовна</div>
                            <div class="carousel__text">Врач стоматолог: <br>гигиенист</div>
                            <button class="btn btn_entry" data-modal="mainModal">Записаться</button>
                        </div>
                    </div>

                    <a href="/vrachi/" class="btn">Все специалисты</a>
                </div>

                <!-- Отзывы -->
                <div class="page-content__chapter">
                    <div class="page-content__title">Отзывы</div>
                    <script src="https://res.smartwidgets.ru/app.js" defer></script>
                    <div class="sw-app" data-app="0f2bd5f81a4db98242a326d90cf8b5c5"></div>
                </div>

            </section>

        </div>
    </div>
</div>


<?php
get_footer();
?>