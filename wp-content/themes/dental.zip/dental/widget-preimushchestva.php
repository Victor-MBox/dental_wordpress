<div class="second-section__item">
    <div class="second-section__column">
        <div><img src="<?php echo bloginfo('template_url'); ?>/assets/img/icons/icon-property-1.svg" alt=""></div>
        <div class="second-section__column-title">Своя <span>лаборатория</span></div>
        <div class="second-section__column-text">Собственное производство, оснащенное современным оборудованием</div>
    </div>

    <div class="second-section__column">
        <div><img src="<?php echo bloginfo('template_url'); ?>/assets/img/icons/icon-property-2.svg" alt=""></div>
        <div class="second-section__column-title">Расширенная <span>гарантия</span></div>
        <div class="second-section__column-text">Мы контролируем производство и установку протезов, поэтому даем на них дополнительную гарантию</div>
    </div>

    <div class="second-section__column">
        <div><img src="<?php echo bloginfo('template_url'); ?>/assets/img/icons/icon-property-3.svg" alt=""></div>
        <div class="second-section__column-title">Фиксированная <span>цена</span></div>
        <div class="second-section__column-text">Никаких скрытых платежей и услуг. Все прозрачно</div>
    </div>

    <div class="second-section__column">
        <div><img src="<?php echo bloginfo('template_url'); ?>/assets/img/icons/icon-property-4.svg" alt=""></div>
        <div class="second-section__column-title">Опытные <span>врачи</span></div>
        <div class="second-section__column-text">Мы тщательно отбираем стоматологов и контролируем их на каждом этапе работы</div>
    </div>
</div>